"""Offline figures from captured data; no vehicle/ROS/SSH access."""
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
source=root/'raw/diagnostics';out=root/'reproduced'
commands=[['review_control_tracking.py',str(source),'--output',str(out/'control_review')],
 ['audit_real_run.py',str(source),'--output-directory',str(out/'analysis')],
 ['plot_race_evidence.py',str(source),'--output',str(out/'figures/real_vehicle_execution')],
 ['plot_paper_details.py',str(source),'--output-directory',str(out/'figures')]]
for name,*args in commands:
 subprocess.run([sys.executable,str(root/'analysis_scripts'/name),*args],check=True)
