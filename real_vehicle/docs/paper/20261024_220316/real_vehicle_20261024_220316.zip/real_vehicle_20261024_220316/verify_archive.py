"""Verify all declared payloads of the extracted acquisition."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
manifest=json.loads((root/'payload_manifest.json').read_text())
for name,row in manifest['files'].items():
 path=Path(name)
 assert not path.is_absolute() and '..' not in path.parts
 data=(root/path).read_bytes()
 assert len(data)==row['size'] and hashlib.sha256(data).hexdigest()==row['sha256'],name
print('Verified',len(manifest['files']),'payload files')
