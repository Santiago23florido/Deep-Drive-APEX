from pathlib import Path
import datetime
import hashlib
import json
import subprocess

out = Path('archive/generated/paper/real_vehicle_20261024_000431/metadata')
before = json.loads((out / 'local_pi_code_parity_before_ram_capture.json').read_text())
remote = '''from pathlib import Path
import json,hashlib,platform,subprocess,email,datetime
root=Path('/home/ensta/AiAtonomousRc/APEX')
environment={'collected_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'collected_after_current_trial':True,
'platform':platform.platform(),'kernel':platform.release(),'os_release':Path('/etc/os-release').read_text(),
'cpuinfo':Path('/proc/cpuinfo').read_text(),'memory':Path('/proc/meminfo').read_text(),
'docker_version':subprocess.check_output(['docker','version','--format','{{json .}}'],text=True).strip(),
'container_image':json.loads(subprocess.check_output(['docker','image','inspect','docker-apex_pipeline:latest'],text=True))[0]}
packages=[]
for folder in [Path('/home/ensta/odom_rt/pylib'),Path('/home/ensta/odom_rt/pylib_b')]:
 for p in sorted(folder.glob('*.dist-info/METADATA')):
  m=email.message_from_string(p.read_text());packages.append({'path':str(p.parent),'name':m['Name'],'version':m['Version']})
selftests={}
for name in ['ram_capture_20261024_000222_6200b8f4.json','ram_capture_20261024_000332_0e672523.json']:
 selftests[name]=json.loads((root/'data/diagnostics'/name).read_text())
'''
remote += '\nfiles=' + repr(before['files']) + '\n'
remote += "for f in files:f['post_trial_remote_sha256']=hashlib.sha256(Path(f['remote']).read_bytes()).hexdigest()\n"
remote += "print(json.dumps({'environment':environment,'packages':packages,'selftests':selftests,'files':files}))\n"
data = json.loads(subprocess.check_output(['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=8', 'raspberrypi', 'python3', '-'], input=remote.encode()))
for f in data['files']:
    assert f['sha256'] == f['post_trial_remote_sha256'], f['local']
    assert hashlib.sha256(Path(f['local']).read_bytes()).hexdigest() == f['sha256'], f['local']
(out / 'local_pi_code_parity_after_ram_capture.json').write_text(json.dumps({
    'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'matching': len(data['files']),
    'all_equal_before_local_and_after_remote': True, 'files': data['files']}, indent=2) + '\n')
(out / 'pi_environment.json').write_text(json.dumps(data['environment'], indent=2) + '\n')
(out / 'pi_odometry_package_versions.json').write_text(json.dumps(data['packages'], indent=2) + '\n')
for name, report in data['selftests'].items():
    (out / name).write_text(json.dumps(report, indent=2) + '\n')
print(f'Post-trial code parity: {len(data["files"])} selected files unchanged on PC and Pi; environment and self-test reports collected.')
