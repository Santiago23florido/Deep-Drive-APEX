from pathlib import Path
import datetime
import hashlib
import json
import subprocess

base = Path('.codex/validation/20261022_open_segment')
diag = base / 'oval_20261024_000431'
meta = Path('archive/generated/paper/real_vehicle_20261024_000431/metadata')
meta.mkdir(parents=True, exist_ok=True)
remote = '''from pathlib import Path
import hashlib,json,subprocess,datetime
root=Path('/home/ensta/AiAtonomousRc/APEX')
paths={'diagnostics':root/'data/diagnostics/20261022_open_segment/oval_20261024_000431',
       'ros_run':root/'ros2_ws/apex_race/20261024_000432',
       'cpu_wrapper':root/'data/diagnostics/20261022_open_segment/cpu_ceiling_20261024_000431'}
entries=[]
for label,folder in paths.items():
 for p in sorted(folder.rglob('*')):
  if p.is_file():entries.append({'path':label+'/'+str(p.relative_to(folder)),'size_bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
report=root/'data/diagnostics/ram_capture_20261024_000431_8d6bd378.json'
entries.append({'path':'diagnostics/ram_storage_postflight.json','size_bytes':report.stat().st_size,'sha256':hashlib.sha256(report.read_bytes()).hexdigest()})
state={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'docker_running':subprocess.check_output(['docker','ps','--format','{{.Names}}'],text=True).splitlines(),
'motor_duty_cycle_ns':int(Path('/sys/class/pwm/pwmchip0/pwm0/duty_cycle').read_text()),
'cpu_max_khz':int(Path('/sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq').read_text()),
'throttled':subprocess.check_output(['vcgencmd','get_throttled'],text=True).strip(),
'temperature':subprocess.check_output(['vcgencmd','measure_temp'],text=True).strip(),
'storage_filesystems':subprocess.check_output(['stat','-f','-c','%T %n',str(root/'ros2_ws/apex_race'),str(root/'data/diagnostics/20261022_open_segment')],text=True).splitlines()}
print(json.dumps({'files':entries,'final_state':state}))
'''
actual = json.loads(subprocess.check_output(['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=8', 'raspberrypi', 'python3', '-'], input=remote.encode()))
folders = {'diagnostics': diag, 'ros_run': base / 'pi_completed_ros_runs/20261024_000432', 'cpu_wrapper': base / 'cpu_ceiling_20261024_000431'}
for entry in actual['files']:
    label, rel = entry['path'].split('/', 1)
    path = folders[label] / rel
    assert path.stat().st_size == entry['size_bytes'], entry['path']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == entry['sha256'], entry['path']
(meta / 'pi_raw_download_verification.json').write_text(json.dumps({
    'verified_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'all_matched': True, 'verified_files': len(actual['files']), 'files': actual['files']}, indent=2) + '\n')
state = actual['final_state']
assert state['motor_duty_cycle_ns'] == 1500000 and not state['docker_running']
assert state['cpu_max_khz'] == 2400000
assert all('tmpfs' not in line for line in state['storage_filesystems'])
(meta / 'final_vehicle_state.json').write_text(json.dumps(state, indent=2) + '\n')
ram = json.loads((diag / 'ram_storage_postflight.json').read_text())
verified, auxiliary = [], []
for label, entry in ram['sha256'].items():
    destination = None
    for prefix, folder in [('diagnostics/oval_20261024_000431/', folders['diagnostics']),
                           ('diagnostics/cpu_ceiling_20261024_000431/', folders['cpu_wrapper']),
                           ('runs/20261024_000432/', folders['ros_run'])]:
        if label.startswith(prefix):
            destination = folder / label[len(prefix):]
            break
    if destination is None:
        auxiliary.append(label)
        continue
    assert destination.stat().st_size == entry['size']
    assert hashlib.sha256(destination.read_bytes()).hexdigest() == entry['sha256']
    verified.append(label)
(meta / 'ram_publication_inventory_verification.json').write_text(json.dumps({
    'published_trial_files_matched': len(verified), 'published_trial_files': verified,
    'temporary_auxiliary_entries_not_published_as_trial_outputs': auxiliary,
    'original_ram_inventory_files': ram['files'], 'original_ram_inventory_bytes': ram['bytes'],
    'copy_and_verify_s': ram['copy_and_verify_s'],
    'scope': 'Every published trial output matched the pre-publication RAM inventory and the live Pi files. Auxiliary root helpers/active marker/last-run pointer are listed separately; their hashes remain in the postflight report. No cryptographic signature is asserted.'}, indent=2) + '\n')
print(json.dumps({'pi_files_verified': len(actual['files']), 'ram_published_files_verified': len(verified), 'auxiliary_inventory_entries': auxiliary, 'final_state': state}, indent=2))
