from pathlib import Path
from importlib.metadata import version
import csv
import datetime
import hashlib
import json
import shutil
import subprocess

base = Path('.codex/validation/20261022_open_segment')
src = base / 'oval_20261024_000431'
out = Path('archive/generated/paper/real_vehicle_20261024_000431')
assert not (out / 'MANIFEST.json').exists(), 'Do not mutate a sealed archive'
old = Path('archive/generated/paper/real_vehicle_20261023_233947')
successful = Path('archive/generated/paper/real_vehicle_20261023_222959')
shutil.copytree(src, out / 'raw/diagnostics', dirs_exist_ok=True,
                ignore=shutil.ignore_patterns('paper', 'paper_audit', 'paper_audit_summary.log', 'motion_effort_summary.log', '__pycache__'))
shutil.copytree(base / 'pi_completed_ros_runs/20261024_000432', out / 'raw/ros_run', dirs_exist_ok=True)
shutil.copytree(base / 'cpu_ceiling_20261024_000431', out / 'raw/cpu_wrapper', dirs_exist_ok=True)
shutil.copytree(src / 'paper', out / 'figures', dirs_exist_ok=True)
shutil.copytree(src / 'paper_audit', out / 'figures', dirs_exist_ok=True)
analysis = out / 'reproducibility/analysis'
analysis.mkdir(parents=True, exist_ok=True)
for name in ['audit_real_run.py', 'test_audit_real_run.py', 'plot_race_evidence.py', 'plot_paper_details.py', 'audit_motion_effort.py']:
    shutil.copy2(Path('real_vehicle/tools/pc') / name, analysis / name)
for name in ['verify_ram_capture_download.py', 'collect_ram_provenance.py', 'package_ram_capture.py']:
    shutil.copy2(base / name, analysis / name)
docs = out / 'reproducibility/source/real_vehicle/docs'
docs.mkdir(parents=True, exist_ok=True)
for name in ['ram_logging.md', 'real_evaluation_protocol.md']:
    shutil.copy2(Path('real_vehicle/docs') / name, docs / name)
meta = out / 'metadata'
controller = out / 'reproducibility/source/real_vehicle/ros2_ws/src/apex_race/apex_race'
original = successful / 'raw/diagnostics/source_snapshot/ros2_ws/src/apex_race/apex_race'
matches = []
for saved in sorted(original.rglob('*.py')):
    rel = saved.relative_to(original)
    assert (controller / rel).read_bytes() == saved.read_bytes(), str(rel)
    matches.append(str(rel))
(meta / 'baseline_controller_equivalence.json').write_text(json.dumps({
    'baseline_run': '20261023_222959', 'tested_run': '20261024_000432',
    'matching_python_core_and_node_files': matches,
    'control_configuration_changed': False, 'model_retrained': False,
    'changes_for_this_trial': ['Host tmpfs overlays for trial CSV/JSON/raw sensor output', 'Passive host resource probe managed by finite runner', 'Preflight host/container tmpfs validation and post-stop SHA256/fsync persistence'],
    'selected_runtime_files_verified_before_and_after': 138}, indent=2) + '\n')
(meta / 'verification_results.json').write_text(json.dumps({
    'tests': {'command': 'python -m pytest -q real_vehicle/ros2_ws/src/apex_telemetry/test/test_ram_trial_storage.py real_vehicle/ros2_ws/src/apex_telemetry/test/test_race_fresh_start.py real_vehicle/tools/pc/test_audit_real_run.py', 'passed': 12, 'duration_s': .73},
    'actual_pi_storage_only_selftests_passed': 2,
    'physical_trial_confirmed_by_operator': True,
    'physical_completed_laps': 2,
    'contact_with_track': 'not reported'}, indent=2) + '\n')
x = json.loads((out / 'figures/real_run_metrics.json').read_text())
m = json.loads((out / 'figures/motion_effort_metrics.json').read_text())
e = json.loads((src / 'race_events.json').read_text())
res = x['execution_resources']
s = x['stationary_10s_before_motion']
cap = json.loads((src / 'sensors/capture_meta.json').read_text())
rows = []
for name, unit, values in [
    ('Hybrid odometry processing', 'ms', x['estimator']['compute_ms']),
    ('Scan stamp to estimate output', 'ms', x['estimator']['latency_ms']),
    ('Propagated pose age at control', 'ms', {k: (v if k == 'n' else v * 1000) for k, v in x['control']['pose_age_s'].items()}),
    ('LiDAR header interval', 'ms', x['raw_sensors']['lidar']['period_ms']),
    ('IMU header interval', 'ms', x['raw_sensors']['imu']['period_ms']),
    ('Odometry CPU', 'percent of one core', res['cpu_percent_one_core']['odometry']),
    ('Driver CPU', 'percent of one core', res['cpu_percent_one_core']['driver']),
    ('Recorder CPU', 'percent of one core', res['cpu_percent_one_core']['recorder']),
    ('Container CPU', 'percent of one core', res['container_cpu_percent_one_core']),
    ('Host CPU', 'percent of all four cores', res['host_cpu_percent_all_cores']),
    ('Odometry RSS', 'MiB', res['rss_mb']['odometry']),
    ('Host memory available', 'MiB', res['host_mem_available_mb']),
    ('Geometric scan consistency score', 'm', x['scan_geometry_consistency']['odom_compensated_capped_mean_residual_m']),
    ('Forward requested ESC command', 'normalized ESC percent', m['bridge']['forward_requested_esc_pct']),
    ('Forward PWM pulse snapshot', 'us', m['bridge']['forward_pwm_pulse_us']),
    ('Onboard temperature (startup and execution)', 'degrees Celsius', x['power']['temperature_c'])]:
    rows.append([name, unit, values['n'], values['mean'], values['p50'], values['p95'], values['max']])
with (out / 'paper_metrics.csv').open('w', newline='') as stream:
    writer = csv.writer(stream)
    writer.writerow(['metric', 'unit', 'n', 'mean', 'median', 'p95', 'maximum'])
    writer.writerows(rows)
tex = ['% Two physical laps confirmed; onboard timing; no external pose ground truth.',
       '\\begin{tabular}{lrrr}', '\\hline', 'Metric & Median & P95 & Max \\\\', '\\hline']
for name, unit, n, mean, median, p95, maximum in rows[:9]:
    u = '\\% core' if unit == 'percent of one core' else unit
    tex.append(f'{name} [{u}] & {median:.2f} & {p95:.2f} & {maximum:.2f} \\\\')
tex += ['\\hline', '\\end{tabular}']
(out / 'paper_timing_table.tex').write_text('\n'.join(tex) + '\n')
shutil.copy2(old / 'verify_archive.py', out / 'verify_archive.py')
(out / 'reproduce_figures.py').write_text('''#!/usr/bin/env python3
from pathlib import Path
import subprocess,sys
r=Path(__file__).resolve().parent;t=r/'reproducibility/analysis';d=r/'raw/diagnostics';f=r/'figures'
commands=[
 [sys.executable,str(t/'audit_real_run.py'),str(d),'--output-directory',str(f)],
 [sys.executable,str(t/'audit_motion_effort.py'),str(d),'--output-directory',str(f)],
 [sys.executable,str(t/'plot_race_evidence.py'),str(d),'--output',str(f/'real_vehicle_execution')],
 [sys.executable,str(t/'plot_paper_details.py'),str(d),'--output-directory',str(f)]]
for command in commands:subprocess.run(command,check=True)
''')
(out / 'requirements-analysis.txt').write_text('\n'.join(p + '==' + version(p) for p in ['numpy', 'scipy', 'matplotlib']) + '\n')
(meta / 'plot_environment.json').write_text(json.dumps({
    'system_python': subprocess.check_output(['python3', '--version'], text=True).strip(),
    'analysis_python': __import__('sys').version,
    'analysis_python_executable': __import__('sys').executable,
    'packages': {p: version(p) for p in ['numpy', 'scipy', 'matplotlib']},
    'collected_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}, indent=2) + '\n')
for name, args in [('git_head.txt', ['git', 'rev-parse', 'HEAD']),
                   ('git_status.txt', ['git', 'status', '--short']),
                   ('working_tree.patch', ['git', 'diff', '--binary'])]:
    (meta / name).write_bytes(subprocess.check_output(args))
previous = out / 'previous_sd_capture'
previous.mkdir(exist_ok=True)
prior_zip = old.with_suffix('.zip')
assert hashlib.sha256(prior_zip.read_bytes()).hexdigest() == '0c6e1d6f2408bae1e3b9f71dca9d07a8f24af37b7ef68272ae5fcf49f1f09b5c'
shutil.copy2(prior_zip, previous / prior_zip.name)
(meta / 'storage_comparison.json').write_text(json.dumps({
    'previous_sd_run': '20261023_233948', 'current_ram_run': '20261024_000432',
    'driver_command_max_gap_ms': {'previous_sd': 309.55, 'current_ram': 42.0},
    'control_core_lock_hold_max_ms': {'previous_sd': 301.5, 'current_ram': 22.4},
    'stop_reason': {'previous_sd': 'actuator_command_gap', 'current_ram': 'driver_done'},
    'onboard_completed_laps': {'previous_sd': 1, 'current_ram': 2},
    'same_controller_config_weights': True, 'controlled_randomized_ablation': False,
    'interpretation': 'RAM capture avoided the previous command-gap interruption in this repeat. Different physical starts, adaptation, recovery sequences and maps prevent assigning all behavior changes exclusively to storage. Actual SD write duration was not instrumented.'}, indent=2) + '\n')
(out / 'README.md').write_text(f'''# Real-vehicle two-lap execution with RAM telemetry capture

ROS run **20261024_000432**; diagnostic ID **20261024_000431**. The operator
confirmed that the vehicle physically completed both laps and stopped. Contact
with track boundaries was not reported either way. Run IDs use the Pi timezone;
the local operator date in Europe/Paris was October 24. Epoch stamps provide
the shared timestamp basis.

## Observed execution

| Interval | Duration | Reverse starts |
|---|---:|---:|
| Reconnaissance lap | {x['laps'][0]['duration_s']:.3f} s | {x['laps'][0]['reverse_starts']} |
| Second lap, including SLAM handover | {x['laps'][1]['duration_s']:.3f} s | {x['laps'][1]['reverse_starts']} |

Stop reason was `driver_done`, after the second recognized line crossing;
execution through final stopping lasted {x['analysis_window_duration_s']:.3f} s.
The arm helper's 129.785 s includes initialization and discovery overhead.
The last crossing preceded `done` by {e['t_done'] - e['crossings'][-1]['t']:.3f} s.
Thus the recorded final stop was the requested two-lap completion, not a
recorded low-power or stale-command stop. The operator perceived low motor power.

Actual execution passed through reconnaissance, overlap, asynchronous global
planning, SLAM-guided local planning and completion. Map guidance began
{e['t_map_guided'] - e['t_explore']:.3f} s after exploration start. The global
candidate was rejected: peak curvature {x['plan']['max_kappa']:.3f} /m exceeded
{x['plan']['kappa_limit']:.3f} /m and map clearance
{x['plan']['min_map_clearance_m']:.4f} m was below the configured 0.10 m gate.
The second lap used the observed SLAM route to guide live-LiDAR local arcs;
it did not directly track the rejected optimized raceline. `raceline.csv`
contains that diagnostic candidate, not a claimed executed trajectory.

## What changed and what was preserved

The successful 20261023_222959 controller, parameters, bridge mapping, model
weights, finite limits and protections were preserved. 138 selected runtime
files matched PC/Pi before launch and remained equal after completion. All
archived controller Python core/node files match that successful reference.
No model was retrained. The added change temporarily directed trial output
trees to host `/dev/shm` tmpfs, verified on both host and Docker paths before
arming, with the existing passive sensor recorder and managed resource probe.
Ordinary OS and Docker/ROS console writes were not globally disabled.

The wrapper stopped writers, confirmed neutral, copied and verified the RAM
tree, fsynced it, restored the original paths, then published the new trial
without overwriting prior data. Persistence and verification took
{json.loads((src / 'ram_storage_postflight.json').read_text())['copy_and_verify_s']:.3f} s
after the motor had stopped. The current 94 published trial files match the
RAM inventory; those files plus the postflight report (95 files) also match
independent hashes read back over SSH. Historical data are preserved.

Both temporary mounts are restored, no Docker container is running, motor
readback is 1500000 ns neutral and the CPU ceiling is restored to 2.4 GHz.
`metadata/final_vehicle_state.json` records the post-trial readback.

## Timing, resources and the slow movement observation

- Driver maximum command publication gap: 42.0 ms, below the unchanged 100 ms
  arm-helper limit. Bridge maximum gap over startup/execution: 71.21 ms;
  bridge timeout samples: 0.
- Maximum control-callback core-lock hold: 22.4 ms. No core-busy stops,
  pose-age stops, stale scans or scan-age stops were recorded. Busy sensor
  callbacks held previous commands; they are not counted as individual stops.
- Hybrid odometry processing median/P95/max:
  {x['estimator']['compute_ms']['p50']:.2f}/{x['estimator']['compute_ms']['p95']:.2f}/{x['estimator']['compute_ms']['max']:.2f} ms.
  This covers feature preparation, ICP/network or stationary hold, deskew and
  integration. It excludes waiting for inputs and output publication; it is
  not isolated neural-network inference time.
- Scan stamp to estimate output-handler entry median/P95:
  {x['estimator']['latency_ms']['p50']:.2f}/{x['estimator']['latency_ms']['p95']:.2f} ms, including acquisition,
  waiting and processing. Propagated pose age at control P95:
  {x['control']['pose_age_s']['p95']*1000:.2f} ms. Propagation is not a new independent
  LiDAR correction at every control tick.
- Mean CPU, odometry/driver/recorder/container:
  {res['cpu_percent_one_core']['odometry']['mean']:.2f}/
  {res['cpu_percent_one_core']['driver']['mean']:.2f}/
  {res['cpu_percent_one_core']['recorder']['mean']:.2f}/
  {res['container_cpu_percent_one_core']['mean']:.2f}% of one core on a four-core Pi 5 at a temporary
  2.0 GHz ceiling. Mean host utilization: {res['host_cpu_percent_all_cores']['mean']:.2f}% across all four cores.
  Driver CPU is close to one core, so computational headroom in that process
  is limited, although the observed command watchdogs did not trip. RSS sums
  can double-count shared pages; odometry mean RSS was {res['rss_mb']['odometry']['mean']:.2f} MiB.

Command time accounting gives 52.947 s of forward commands, 39.737 s of reverse
commands and 34.137 s of zero/deadband commands across execution. These are
zero-order holds of driver rows with a 0.005 m/s mapping threshold, not measured
physical-motion durations. The second lap included 9.380 s of reverse commands
and 7.297 s of zero/deadband commands. `lap_command_budget.csv` supplies exact
values; rounding and driver-row update times limit boundary precision.

Positive bridge snapshots had a median requested ESC command of
{m['bridge']['forward_requested_esc_pct']['p50']:.3f}, maximum
{m['bridge']['forward_requested_esc_pct']['max']:.3f}, below the 28.2 ceiling
in every snapshot. Median forward PWM readback was
{m['bridge']['forward_pwm_pulse_us']['p50']:.3f} microseconds (neutral: 1500).
The bridge uses `15 + 33*u` for positive command `u`; at approximately
0.035 m/s this gives 16.155. This normalized ESC percentage is not percent
electrical power or PWM duty cycle. The displayed legacy minimum of 17 is
not imposed by the active affine profile; 76.35% of positive snapshots were
below that parameter. The current physical breakaway threshold is unmeasured.
The forward ceiling was therefore not the limiting software bound in this run.

Final longitudinal identification accepted only one update, with speed offset
0.1343 m/s and gain 0.8799; overall confidence remained zero. The speed shaper
inverts this offset and adds bounded speed feedback and standstill launch
compensation. This identifies a software mechanism for small forward commands,
but does not isolate the physical reason for weak propulsion. It is not a
well-identified motor model or independent motion calibration.

No live Pi undervoltage/throttle flags were sampled; maximum logged temperature
was {x['power']['temperature_c']['max']:.1f} degrees Celsius. Pi supply flags do not measure motor terminal
voltage or current and cannot establish battery charge or motor power. The
records support low commands and maneuver time as visible contributors to slow
progress. They do not prove that battery weakness was absent, or that all ROS
scheduling effects were absent.

The preceding SD-capture attempt stopped at a 309.55 ms source command gap and
301.5 ms control-lock hold. RAM capture avoided that interruption in this run.
This is an engineering repeat with the same code, not a randomized causal
ablation: initial placement, adaptation, maps and recovery sequences differ.
The actual SD write latency was not instrumented. Full earlier evidence,
including the original successful archive, is included intact under
`previous_sd_capture/real_vehicle_20261023_233947.zip`.

## Data completeness and ground-truth-free diagnostics

Captured {cap['counts']['imu']} raw IMU samples, {cap['counts']['scans']} raw 360-beam LiDAR scans and
17434 receipt records. All recorded counts agree with capture metadata, critical
driver/estimator values are finite, timestamps increase, and raw rows have the
expected schema. The recorder is best effort; complete files do not establish
lossless sensor transport. Non-return LiDAR ranges retain `inf` as expected.

During execution there were 12701 IMU and 1255 LiDAR records; IMU header rate
was {x['raw_sensors']['imu']['active_header_rate_hz']:.3f} Hz without a gap above 15 ms. LiDAR header rate was
{x['raw_sensors']['lidar']['active_header_rate_hz']:.3f} Hz, with six intervals above 150 ms and a largest interval
of {x['raw_sensors']['lidar']['period_ms']['max']:.3f} ms. These timing anomalies remain in the data and triggered no
recorded stale-data stop. Header age includes the roughly 100 ms sweep; it is
not an isolated ROS queue delay. Captured active estimate count was 1255.

The stationary pre-motion check spans {s['observed_duration_s']:.3f} s and reports maximum
displacement from its first pose {s['max_displacement_from_first_m']*1000:.3f} mm, with stationary hold active
throughout. This is hybrid-pipeline stationary behavior, not isolated model
accuracy. Scan consistency evaluates 914 consecutive deskewed pairs with
7-neighbor planar PCA, coverage gates and a 0.20 m unmatched-point penalty;
mean score {x['scan_geometry_consistency']['odom_compensated_capped_mean_residual_m']['mean']*100:.3f} cm. Poses and deskew depend on the same estimator.
This is correlated geometric self-consistency, not ATE/RPE, drift or absolute
position error. The identity-pose trace is a diagnostic, not a competitive
odometry baseline. No external ground truth or video was available.

The archive contains saved occupancy and graph vertices, not a full ROS bag
or serialized SLAM factor graph. Logs include learned/propagated estimates,
uncertainty, adaptation, inputs, commands, nominal steering, PWM readbacks,
recovery events, route/global candidate, all finite-trial guards, raw sensor
timing, power/temperature and passive process CPU/RSS samples. Sources, model
weights, configuration, image ID, environment, self-test reports and checksums
support reproduction. These experiments involved previous on-car engineering
adjustments and online adaptation; unchanged model weights alone do not establish
untouched zero-shot transfer of the full stack or statistical reliability.

## English figures and offline reproduction

- `figures/real_vehicle_execution.pdf`: map, estimated trajectory, commands and lap count.
- `figures/slam_map_and_laps.pdf`: reconnaissance and second-lap estimates.
- `figures/slam_handover_detail.pdf`: actual continuous handover.
- `figures/single_run_lap_comparison.pdf`: both laps from this same run.
- `figures/real_odometry_and_timing.pdf`: processing, sensor ages, consistency and stationary stability.
- `figures/raspberry_resources.pdf`: active per-process CPU and RSS.

Each plot has vector PDF/SVG and 600 dpi PNG output. Captions, plotted CSVs,
`paper_metrics.csv`, `paper_timing_table.tex`, full JSON definitions and command
time accounting are included. No car or ROS is required for plotting.

Run `python3 verify_archive.py` before modifying the package. Install the exact
versions in `requirements-analysis.txt`, then run `python3 reproduce_figures.py`.
PDF creation dates may change hashes on regeneration. The packaged geometry
sanity test is `reproducibility/analysis/test_audit_real_run.py`; it checks known
box motion and coordinate-frame invariance. Scripts for original SSH collection
are preserved for provenance and are not needed by the offline reproducer.
''')
print(f'Assembled {out}; run offline reproduction, then seal checksums.')
