#!/usr/bin/env python3
from pathlib import Path
import subprocess,sys
r=Path(__file__).resolve().parent;t=r/'reproducibility/analysis';d=r/'raw/diagnostics';f=r/'figures'
commands=[
 [sys.executable,str(t/'audit_real_run.py'),str(d),'--output-directory',str(f)],
 [sys.executable,str(t/'audit_motion_effort.py'),str(d),'--output-directory',str(f)],
 [sys.executable,str(t/'plot_race_evidence.py'),str(d),'--output',str(f/'real_vehicle_execution')],
 [sys.executable,str(t/'plot_paper_details.py'),str(d),'--output-directory',str(f)]]
for command in commands:subprocess.run(command,check=True)
