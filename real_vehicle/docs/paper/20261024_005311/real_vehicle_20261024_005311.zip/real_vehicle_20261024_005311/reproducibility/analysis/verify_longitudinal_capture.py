from pathlib import Path
import datetime
import hashlib
import json
import subprocess

base = Path('.codex/validation/20261022_open_segment')
diag = base / 'oval_20261024_005311'
pre = json.loads((base / 'longitudinal_gate_preflight/local_pi_code_parity_before_trial.json').read_text())
remote = '''from pathlib import Path
import hashlib,json,subprocess,datetime
r=Path('/home/ensta/AiAtonomousRc/APEX')
paths={'diagnostics':r/'data/diagnostics/20261022_open_segment/oval_20261024_005311',
'ros_run':r/'ros2_ws/apex_race/20261024_005311',
'cpu_wrapper':r/'data/diagnostics/20261022_open_segment/cpu_ceiling_20261024_005310'}
files=[]
for label,folder in paths.items():
 for p in sorted(folder.rglob('*')):
  if p.is_file():files.append({'path':label+'/'+str(p.relative_to(folder)),'size_bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
p=r/'data/diagnostics/ram_capture_20261024_005310_fa87a399.json'
files.append({'path':'diagnostics/ram_storage_postflight.json','size_bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
state={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'docker_running':subprocess.check_output(['docker','ps','--format','{{.Names}}'],text=True).splitlines(),
'motor_duty_cycle_ns':int(Path('/sys/class/pwm/pwmchip0/pwm0/duty_cycle').read_text()),
'cpu_max_khz':int(Path('/sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq').read_text()),
'throttled':subprocess.check_output(['vcgencmd','get_throttled'],text=True).strip(),
'temperature':subprocess.check_output(['vcgencmd','measure_temp'],text=True).strip(),
'storage_filesystems':subprocess.check_output(['stat','-f','-c','%T %n',str(r/'ros2_ws/apex_race'),str(r/'data/diagnostics/20261022_open_segment')],text=True).splitlines()}
'''
remote += '\ncode=' + repr(pre['files']) + '\n'
remote += "for f in code:f['postflight_remote_sha256']=hashlib.sha256(Path(f['remote']).read_bytes()).hexdigest()\n"
remote += "print(json.dumps({'files':files,'code':code,'state':state}))\n"
data = json.loads(subprocess.check_output(['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=8', 'raspberrypi', 'python3', '-'], input=remote.encode()))
folders = {'diagnostics': diag, 'ros_run': base / 'pi_completed_ros_runs/20261024_005311', 'cpu_wrapper': base / 'cpu_ceiling_20261024_005310'}
for entry in data['files']:
    label, name = entry['path'].split('/', 1);p = folders[label] / name
    assert p.stat().st_size == entry['size_bytes'] and hashlib.sha256(p.read_bytes()).hexdigest() == entry['sha256'], entry['path']
for file in data['code']:
    assert file['sha256'] == file['postflight_remote_sha256'] == hashlib.sha256(Path(file['local']).read_bytes()).hexdigest(), file['local']
state = data['state']
assert state['motor_duty_cycle_ns'] == 1500000 and not state['docker_running'] and state['cpu_max_khz'] == 2400000
assert all('tmpfs' not in line for line in state['storage_filesystems'])
(diag / 'pi_raw_download_verification.json').write_text(json.dumps({'all_matched': True, 'verified_files': len(data['files']), 'files': data['files']}, indent=2) + '\n')
(diag / 'local_pi_code_parity_after_trial.json').write_text(json.dumps({'matching': len(data['code']), 'unchanged_during_trial': True, 'files': data['code']}, indent=2) + '\n')
(diag / 'final_vehicle_state.json').write_text(json.dumps(state, indent=2) + '\n')
ram = json.loads((diag / 'ram_storage_postflight.json').read_text());count = 0
for name, entry in ram['sha256'].items():
    for prefix, folder in [('diagnostics/oval_20261024_005311/', folders['diagnostics']), ('diagnostics/cpu_ceiling_20261024_005310/', folders['cpu_wrapper']), ('runs/20261024_005311/', folders['ros_run'])]:
        if name.startswith(prefix):
            p = folder / name[len(prefix):]
            assert p.stat().st_size == entry['size'] and hashlib.sha256(p.read_bytes()).hexdigest() == entry['sha256']
            count += 1
(diag / 'ram_inventory_verification.json').write_text(json.dumps({'published_trial_files_matched': count, 'auxiliary_helpers_and_pointers_listed_in_original_report': True, 'original_ram_inventory_files': ram['files']}, indent=2) + '\n')
print(json.dumps({'pi_raw_files_verified': len(data['files']), 'runtime_source_matches': len(data['code']), 'ram_published_files_verified': count, 'final_state': state}, indent=2))
