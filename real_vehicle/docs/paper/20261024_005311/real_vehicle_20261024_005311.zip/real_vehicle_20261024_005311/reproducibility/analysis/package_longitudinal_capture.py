"""Assemble this new trial separately from all sealed approved captures."""
from pathlib import Path
from importlib.metadata import version
import csv
import datetime
import hashlib
import json
import shutil
import subprocess
import sys
import zipfile

base = Path('.codex/validation/20261022_open_segment')
diag_id = '20261024_005311'
run_id = '20261024_005311'
cpu_id = '20261024_005310'
src = base / ('oval_' + diag_id)
out = Path('archive/generated/paper') / ('real_vehicle_' + diag_id)
assert not (out / 'MANIFEST.json').exists(), 'Sealed evidence must remain immutable'
out.mkdir(parents=True, exist_ok=True)
shutil.copytree(src, out / 'raw/diagnostics', dirs_exist_ok=True,
                ignore=shutil.ignore_patterns('paper', 'paper_audit', '*summary.log', '__pycache__'))
shutil.copytree(base / 'pi_completed_ros_runs' / run_id, out / 'raw/ros_run', dirs_exist_ok=True)
shutil.copytree(base / ('cpu_ceiling_' + cpu_id), out / 'raw/cpu_wrapper', dirs_exist_ok=True)
shutil.copytree(base / 'longitudinal_gate_preflight/source', out / 'reproducibility/source', dirs_exist_ok=True)
meta = out / 'metadata';meta.mkdir(exist_ok=True)
for name in ['local_pi_code_parity_before_trial.json', 'control_change.patch', 'tests.log']:
    shutil.copy2(base / 'longitudinal_gate_preflight' / name, meta / name)
for name in ['pi_raw_download_verification.json', 'final_vehicle_state.json', 'local_pi_code_parity_after_trial.json']:
    if (src / name).exists():shutil.copy2(src / name, meta / name)
shutil.copytree(src / 'paper', out / 'figures', dirs_exist_ok=True)
shutil.copytree(src / 'paper_audit', out / 'figures', dirs_exist_ok=True)
analysis = out / 'reproducibility/analysis';analysis.mkdir(parents=True, exist_ok=True)
for name in ['audit_real_run.py', 'audit_motion_effort.py', 'test_audit_real_run.py', 'plot_race_evidence.py', 'plot_paper_details.py']:
    shutil.copy2(Path('real_vehicle/tools/pc') / name, analysis / name)
shutil.copy2(Path(__file__), analysis / Path(__file__).name)
previous = Path('archive/generated/paper/real_vehicle_20261024_000431')
for name in ['pi_environment.json', 'pi_odometry_package_versions.json']:
    shutil.copy2(previous / 'metadata' / name, meta / ('previous_environment_' + name))
(meta / 'environment_scope.json').write_text(json.dumps({
    'environment_reports_reference_run': '20261024_000432',
    'note': 'OS/image/library reports were collected for the earlier same-session run. They are labeled previous, not claimed as freshly measured during this trial. New preflight, source hashes, live resources and final state are supplied separately.'}, indent=2) + '\n')
for name, args in [('git_head.txt', ['git', 'rev-parse', 'HEAD']), ('git_status.txt', ['git', 'status', '--short'])]:
    (meta / name).write_bytes(subprocess.check_output(args))
x = json.loads((out / 'figures/real_run_metrics.json').read_text())
m = json.loads((out / 'figures/motion_effort_metrics.json').read_text())
events = json.loads((src / 'race_events.json').read_text())
feedback = json.loads((src / 'operator_feedback.json').read_text()) if (src / 'operator_feedback.json').exists() else {}
comparisons = []
for label, file, event_file in [
    ('Original fast run', base / 'original_222959_motion_comparison/motion_effort_metrics.json', Path('archive/generated/paper/real_vehicle_20261023_222959/raw/diagnostics/race_events.json')),
    ('Previous full capture', previous / 'figures/motion_effort_metrics.json', previous / 'raw/diagnostics/race_events.json'),
    ('Longitudinal confidence gate', out / 'figures/motion_effort_metrics.json', src / 'race_events.json')]:
    z = json.loads(file.read_text());e = json.loads(event_file.read_text());bounds = [e['t_explore']] + [c['t'] for c in e.get('crossings', [])]
    row = {'trial': label, 'run_id': z['run_id'], 'completed_onboard_laps': len(e.get('crossings', [])),
           'lap1_s': bounds[1] - bounds[0] if len(bounds) > 1 else '',
           'lap2_s': bounds[2] - bounds[1] if len(bounds) > 2 else '',
           'forward_esc_snapshot_median': z['bridge']['forward_requested_esc_pct']['p50'],
           'forward_command_time_weighted_median_mps': z['intervals'][-1]['forward_command_mps']['p50'],
           'driver_command_max_gap_ms': e.get('cmd_gap_max_ms'),
           'effective_v_gain_final': e['adaptation']['v_gain'],
           'effective_v_offset_final': e['adaptation']['v_offset']}
    comparisons.append(row)
with (out / 'run_comparison.csv').open('w', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=list(comparisons[0]));writer.writeheader();writer.writerows(comparisons)
res = x['execution_resources'];rows = []
for label, unit, value in [
    ('Hybrid odometry processing', 'ms', x['estimator']['compute_ms']),
    ('Scan stamp to estimate output', 'ms', x['estimator']['latency_ms']),
    ('Propagated pose age at control', 'ms', {k: v if k == 'n' else v * 1000 for k,v in x['control']['pose_age_s'].items()}),
    ('Odometry CPU', 'percent of one core', res['cpu_percent_one_core']['odometry']),
    ('Driver CPU', 'percent of one core', res['cpu_percent_one_core']['driver']),
    ('Recorder CPU', 'percent of one core', res['cpu_percent_one_core']['recorder']),
    ('Container CPU', 'percent of one core', res['container_cpu_percent_one_core']),
    ('Odometry RSS', 'MiB', res['rss_mb']['odometry']),
    ('Scan consistency score', 'm', x['scan_geometry_consistency']['odom_compensated_capped_mean_residual_m'])]:
    rows.append([label, unit, value['n'], value['mean'], value['p50'], value['p95'], value['max']])
with (out / 'paper_metrics.csv').open('w', newline='') as stream:
    writer = csv.writer(stream);writer.writerow(['metric', 'unit', 'n', 'mean', 'median', 'p95', 'maximum']);writer.writerows(rows)
(out / 'requirements-analysis.txt').write_text('\n'.join(p + '==' + version(p) for p in ['numpy', 'scipy', 'matplotlib']) + '\n')
(out / 'reproduce_figures.py').write_text('''from pathlib import Path
import subprocess,sys
r=Path(__file__).resolve().parent;t=r/'reproducibility/analysis';d=r/'raw/diagnostics';f=r/'figures'
for command in [[sys.executable,str(t/'audit_real_run.py'),str(d),'--output-directory',str(f)], [sys.executable,str(t/'audit_motion_effort.py'),str(d),'--output-directory',str(f)], [sys.executable,str(t/'plot_race_evidence.py'),str(d),'--output',str(f/'real_vehicle_execution')], [sys.executable,str(t/'plot_paper_details.py'),str(d),'--output-directory',str(f)]]:subprocess.run(command,check=True)
''')
shutil.copy2(previous / 'verify_archive.py', out / 'verify_archive.py')
lap_lines = '\n'.join(f"- Lap {r['lap']}: {r['duration_s']:.3f} s, {r['reverse_starts']} reverse starts." for r in x['laps'])
(out / 'README.md').write_text(f'''# Real vehicle: longitudinal-confidence-gated repeat

ROS run **{run_id}**, diagnostic **{diag_id}**. This is a new controller change,
separate from the earlier operator-approved 000432 capture and its Git tag.
Run IDs use Pi local time; epoch stamps are the shared time basis. Operator
date was October 24, 2026 (Europe/Paris).

## Outcome

Stop reason: **{x['stop_reason']}**. Exploration-to-recorded-end interval:
{x['analysis_window_duration_s']:.3f} s. Onboard completed laps: {len(x['laps'])}.
{lap_lines}

The operator-confirmation record is retained in `raw/diagnostics/operator_feedback.json`.
Observations are included only when supplied; unknown outcomes remain explicit:
```json
{json.dumps(feedback, ensure_ascii=False, indent=2)}
```
Onboard lap counts and operator observations are distinct evidence. Contact
with track boundaries must not be inferred if it was not reported.

## Exact control change

The speed Kalman block continues identifying gain and offset from odometry.
Its inverse reaches the control only after `conf_long >= 0.5` (including the
existing minimum update count) and consistent residuals (`chi <= chi_max`).
Before that, effective speed gain/offset remain 1/0, as in the original fast
run. Lateral confidence is independent. Steering adaptation, deadband/launch
learning, model weights, map mode, PWM caps, finite mission and guards are
unchanged. Shared real/SIM `plant_id.py` copies are identical. A new regression
test exercises a single reverse observation, repeated collinear observations,
identified speed parameters with zero lateral confidence, and residual rejection.
221 tests passed, 3 ROS skips and 3 slow deselections; test output is included.
Before launch all 138 selected PC/Pi files matched; only the runtime plant
identifier differs from the approved source. Exact source, weights, patch and
preflight/postflight parity are retained. The prior approved Git tag was not
changed by this experiment.

Final effective and raw speed estimates, confidence and application flag:
```json
{json.dumps(m['adaptation_final'], indent=2)}
```
These separate what the estimator fitted from what control used. No network
weights were retrained. This engineering repeat does not establish untouched
zero-shot full-stack transfer or statistical reliability.

## Data, timing and execution

The same passive raw IMU/LiDAR and CPU/RSS capture writes trial CSV/JSON to host
tmpfs, verified inside Docker before arm. After writers stop and PWM is neutral,
the wrapper copies to SD, verifies SHA256/sizes, fsyncs, restores mounts and
publishes new paths without overwriting older evidence. Ordinary OS/Docker/ROS
console writes are not globally disabled. Postflight storage and independent
SSH hash checks are included. No per-command detailed timing probe was added.

`real_run_metrics.json` defines all windows/percentiles. Hybrid processing
includes features, ICP/network or stationary hold, deskew and integration,
excluding input waiting/output publication. Header age includes sweep acquisition
and waiting. Propagated pose freshness is not a new independent LiDAR correction.
Driver maximum command publication gap was {x['runtime']['driver_command_max_gap_ms']:.2f} ms;
bridge timeout samples: {x['runtime']['bridge_timeout_samples']}. Pi live fault
samples: {x['power']['live_fault_samples']}; these are not motor voltage/current
measurements. The recorder is best effort: complete files do not establish
lossless sensor transport. Timing anomalies remain in the raw data and metrics.

Actual executed phases are shown in the figures. Check `raw/diagnostics/plan.json`
for global candidate acceptance: map-guided local planning must not be described
as direct tracking of a rejected candidate. Coordinates, distances and speeds
are onboard estimates. No external ground truth or motor electrical sensing
was available. Scan geometry and stationary stability are correlated diagnostics
of the deployed hybrid estimator, not ATE/RPE, drift or absolute position error.

`run_comparison.csv` compares original fast, previous full capture and current
trial. Different starts, maps, online estimates and unmeasured battery state
make these engineering comparisons, not controlled causal ablations. Positive
ESC snapshot distributions are not time-weighted and are not electrical power.
Command duration accounting uses zero-order holds, not physical-motion duration.
CPU 100% means one core; RSS sums may double-count shared pages.

## English figures and reproduction

`figures/` supplies English vector PDF/SVG and 600 dpi PNG for execution,
SLAM/laps, handover, within-run lap comparison when two crossings exist,
odometry/timing and active Raspberry resources. Tables, plotted traces and
captions accompany them. Source and models are under `reproducibility/source`;
analysis requires no ROS or car. Earlier OS/image/library reports are explicitly
labeled previous; live new preflight/source/resources/final state are retained.

Run `python3 verify_archive.py` before modifying a sealed package. With versions
from `requirements-analysis.txt`, run `python3 reproduce_figures.py` offline.
Regeneration can change PDF timestamps and therefore hashes. Geometry sanity
tests are in `reproducibility/analysis/test_audit_real_run.py`.
''')
print('Assembled', out)
