#!/usr/bin/env python3
"""Verify archived payload sizes and SHA256 digests without hardware access."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent
manifest = json.loads((root / 'MANIFEST.json').read_text())
expected = {entry['path'] for entry in manifest['files']} | {'MANIFEST.json', 'SHA256SUMS'}
actual = {str(file.relative_to(root)) for file in root.rglob('*') if file.is_file()}
assert actual == expected, 'Archive file inventory differs from manifest'
for entry in manifest['files']:
    file = root / entry['path']
    assert file.is_file(), f'Missing: {entry["path"]}'
    assert file.stat().st_size == entry['size_bytes'], f'Size mismatch: {entry["path"]}'
    assert hashlib.sha256(file.read_bytes()).hexdigest() == entry['sha256'], f'Hash mismatch: {entry["path"]}'
print(f'PASS: {len(manifest["files"])} files match the archive manifest.')
